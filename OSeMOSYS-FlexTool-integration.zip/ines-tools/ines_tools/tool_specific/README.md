## Tool/model specific scripts and templates

The folders here can contain tool specific scripts and templates, but as this cannot be separately version controlled, 
the best practices is to establish separate repositories for every tool/model.

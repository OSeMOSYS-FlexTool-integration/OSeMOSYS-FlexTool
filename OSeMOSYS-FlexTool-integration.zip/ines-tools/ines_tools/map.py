def map_preprocess(iodb):
    return

def map_postprocess(iodb):
    return

# Function map for entity classes; specific to the generic structure
def map_constraint(iodb,entities,parameters):
    return

def map_link(iodb,entities,parameters):
    return

def map_node(iodb,entities,parameters):
    return

def map_period(iodb,entities,parameters):
    return

def map_set(iodb,entities,parameters):
    return

def map_solve_pattern(iodb,entities,parameters):
    return

def map_system(iodb,entities,parameters):
    return

def map_temporality(iodb,entities,parameters):
    return

def map_tool(iodb,entities,parameters):
    return

def map_unit(iodb,entities,parameters):
    return

def map_node__to_unit(iodb,entities,parameters):
    return

def map_set__link(iodb,entities,parameters):
    return

def map_set_node(iodb,entities,parameters):
    return

def map_set_temporality(iodb,entities,parameters):
    return

def map_set__unit(iodb,entities,parameters):
    return

def map_tool_set(iodb,entities,parameters):
    return

def map_unit__to_node(iodb,entities,parameters):
    return

def map_node__link__node(iodb,entities,parameters):
    return

def map_set__node__temporality(iodb,entities,parameters):
    return

def map_set__node__unit(iodb,entities,parameters):
    return
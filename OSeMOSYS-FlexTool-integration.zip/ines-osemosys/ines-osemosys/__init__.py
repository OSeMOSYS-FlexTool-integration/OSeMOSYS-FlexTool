"""
Init file for ines-osemosys.
"""
__version__ = "0.0.1"

from ines_osemosys import *
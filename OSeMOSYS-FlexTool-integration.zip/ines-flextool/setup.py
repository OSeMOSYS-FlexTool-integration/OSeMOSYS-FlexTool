from setuptools import setup

# NOTE: package configuration moved to setup.cfg
setup()
